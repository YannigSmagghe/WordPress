<?php
$NomSite = $_POST["NomSite"];
$dbname = $_POST["dbname"];
$dbuser = $_POST["dbuser"];
$dbpass = $_POST["dbpass"];
$url = $_POST["url"];
$title = $_POST["title"];
$admin_user = $_POST["admin_user"];
$admin_password = $_POST["admin_password"];
$admin_email = $_POST["admin_email"];

exec("curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar");
exec("php wp-cli.phar --info");
exec("chmod +x wp-cli.phar");
exec("sudo mv wp-cli.phar /usr/local/bin/wp");
exec("wp core download ");
exec("wp core config --dbname=".$dbname." --dbuser=root --dbpass=0000 --locale=en_EN ");
exec("wp db create " . $dbname);

exec("wp core install --url=" . $url . " --title=" . $title . " --admin_user=root --admin_password=0000 --admin_email=" . $admin_email . " --skip-email ");

exec("git clone https://github.com/chloebeaufils/tpWordpress1.git");
exec("cp tpWordpress1/data/apache2.conf /etc/apache2/apache2.conf ");
exec("Sudo a2enmod rewrite");
exec("cp tpWordpress1/data/envvars /etc/apache2/envvars");
exec("sudo service apache2 restart");


$fname = "tpWordpress1/data/Vagrantfile.php";
$fhandle = fopen($fname,"r");
$content = fread($fhandle,filesize($fname));
$content = str_replace("192.168.33.10", "localhost", $content);

$fhandle = fopen($fname,"w");
fwrite($fhandle,$content);
fclose($fhandle);
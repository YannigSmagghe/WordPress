<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'yannDb' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '0000' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1n@wa58Q_D9`V_]DoW*muhO jM@O((|Of8f}z1iHabA3Q/Rv(D:t(}1rH46p<W!9');
define('SECURE_AUTH_KEY',  '8H#jr?h@*XM2Cm4Xm<Z3P+c,Kzf+Wv2eBBQpEv2ts&g#u`}[J|oQ-mFJ_>(J}en.');
define('LOGGED_IN_KEY',    'm86Of+K7(&JDp;GwLRA:R})XQ[-eX>lC_Kg|k@7`tn>O|5yD(z?1Wn%!YgtC1/x#');
define('NONCE_KEY',        't;&a gq^SJb/%Ry4<q@ 2Yp>lg^W~yA7+2Z8Me :)R^=6E |g4(a?8nuEY,YJjF7');
define('AUTH_SALT',        'q`lzBRg`{$_Wk9k0w&T.GiH6!=L=D?HV+<e8-C$VIz)7[?v#.X+g2Bq(3T$wXxDA');
define('SECURE_AUTH_SALT', 'jZp fxSP*vu.g|CFS@q--EAK2hZ0qrI,F)*hj2XTv~^iPRnJE-[,|+NIpOyh8dbd');
define('LOGGED_IN_SALT',   'G+$68q#i7wxp=U+]Qxe_Ez?u-[he53@p6<j.6fT4+$l218*V3?LYy8EM1(-+!u|:');
define('NONCE_SALT',       '/4wyta_Whf_:8..OiHqL>A[6#$R Dg4K5j+ZXoojIbxPty11#-5$-V1m)6jVm%zq');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

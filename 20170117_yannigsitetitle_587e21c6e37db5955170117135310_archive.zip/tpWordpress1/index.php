<!DOCTYPE html>
<html>
<head>
<title>Form wp</title>
</head>

<body>
  <form action="traitement.php" method="post">
     <!-- dbname -->
     <p>NomSite : <input type="text" name="NomSite" /></p>
     <!-- dbname -->
     <p>Dbname : <input type="text" name="dbname" /></p>
     <!-- dbuser -->
  <!--    <p>Dbuser : <input type="text" name="dbuser" /></p>-->
  <!--    <!-- dbpass -->
  <!--    <p>Dbpass : <input type="text" name="dbpass" /></p>-->
     <!-- url -->
     <p>Url : <input type="text" name="url" /></p>
     <!-- title -->
     <p>Title : <input type="text" name="title" /></p>
     <!-- admin_user -->
  <!--    <p>Admin_user : <input type="text" name="admin_user" /></p>-->
     <!-- admin_password -->
  <!--    <p>Admin_password : <input type="text" name="admin_password" /></p>-->
  <!--     admin_email -->
     <p>Admin_email : <input type="text" name="admin_email" /></p>
     <p><input type="submit" value="OK"></p>
  </form>
</body>

</html>
